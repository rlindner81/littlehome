package jalgebra.impl.set;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.algo.*;
import jalgebra.impl.object.Integer;
import jalgebra.impl.object.*;
import jalgebra.impl.ring.*;




/**
 * The set of polynomials from a primepower field
 */
public class PrimePowerFieldSet implements Set {

	protected PolynomialRing R; //the whole polynomial ring
	protected AbelianGroup Radd;
	protected Monoid Rmul;
	
	protected FiniteField F; //the ground field
	protected AbelianGroup Fadd; 
	protected AbelianGroup Fmul; 

	protected Integers Z = new Integers(); 
	protected AbelianGroup Zadd = (AbelianGroup)Z.add();
	protected Monoid Zmul = (Monoid)Z.mul();
	protected Polynomial p; //the irreducible polynomial
	protected int pd;
	protected Object pdeg;
	
	
	protected Object order;
	protected Object zero;
	protected Object one;




	//Constructor
    public PrimePowerFieldSet(FiniteField _F, Polynomial _p) {
		F = _F;
		Fadd = (AbelianGroup)F.add();
		Fmul = (AbelianGroup)F.mul();
		
		R = new PolynomialRing(F);
		Radd = (AbelianGroup)R.add();
		Rmul = (Monoid)R.mul();
		
		p = _p;
		pd = p.getDegree();
		pdeg = new Integer(pd);
		zero = Radd.neutral();
		one = Rmul.neutral();

		order = Z._copy(F.getOrder());
		GroupAlgorithm._pow(Z.mul(),order,Z,pdeg);
	}




    public boolean in(Object _x) {
    	if(!(_x instanceof Polynomial)) return false;
    	Polynomial x = (Polynomial)_x;
    	
    	int xd = x.getDegree();
		if(xd==Polynomial.MINUS_INFINITY) return true;
    	if(xd>=pd) return false;

    	Object o;
    	for(int i=0;i<=xd;i++){
    		o = x.getCo(i);
    		if(o != null && !F.in(o)) return false;
    	}
    	return true;
    }

    public boolean eq(Object x, Object y) {
    	if (in(x) && in(y)) return _eq(x,y);
    	else throw new MathException("Tried to equals on non-PrimePowerField element.");
	}
    public boolean _eq(Object _x, Object _y) {
    	return R._eq(_x,_y);
    }

    public Object copy(Object o) {
		if (in(o)) return _copy(o);
		else throw new MathException("Tried to copy with non-PrimePowerField element.");
    }
    public Object _copy(Object o) {
    	return R._copy(o);
    }




}