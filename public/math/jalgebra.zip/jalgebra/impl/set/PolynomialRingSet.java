package jalgebra.impl.set;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.*;




/**
 * The set of polynomials from a polynomial ring
 */
public class PolynomialRingSet implements Set {

	protected Ring R; //the ground ring
	protected AbelianGroup Radd; 
	protected Monoid Rmul; 
	protected Polynomial zero;
	protected Polynomial one;




	//Constructor
    public PolynomialRingSet(Ring _R) {
		R = _R;
		Radd = (AbelianGroup)R.add();
		Rmul = (Monoid)R.mul();
		zero = new Polynomial(R);
		one = new Polynomial(R,0);
	}




	//Special methods 
	protected Ring getRing(){
		return R;
	}




	// Set requirements
	// I have to trust the user here to use the same ring for the polynomial and the polynomialring
    public boolean in(Object _x) {
    	if(!(_x instanceof Polynomial)) return false;
    	Polynomial x = (Polynomial)_x;
    	
    	int xd = x.getDegree();
    	if(xd==Polynomial.MINUS_INFINITY) return true;
    	Object o;
    	for(int i=0;i<=xd;i++){
    		o = x.getCo(i);
    		if(o != null && !R.in(o)) return false;
    	}
		return true;
    }

    public boolean eq(Object x, Object y) {
    	if (in(x) && in(y)) return _eq(x,y);
    	else throw new MathException("Tried to equals on non-ring element.");
	}
    public boolean _eq(Object _x, Object _y) {
    	Polynomial x = (Polynomial)_x;
    	Polynomial y = (Polynomial)_y;
		if(x == null) x = zero;
		if(y == null) y = zero;
		
		int xd = x.getDegree();
		int yd = y.getDegree();
		
		if(xd!=yd) return false;
		if(xd==jalgebra.impl.object.Polynomial.MINUS_INFINITY) return true;
    	
    	for (int i=0; i<=xd;i++) 
    		if(!R._eq(x.getCo(i),y.getCo(i))) return false;
    	return true;
    }

    public Object copy(Object o) {
		if (in(o)) return _copy(o);
		else throw new MathException("Tried to copy with non-PolyRing element.");
    }
    public Object _copy(Object o) {
    	return new Polynomial((Polynomial)o);
    }




}