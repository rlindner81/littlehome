package jalgebra.impl.set;

import jalgebra.intf.structure.Set;
import jalgebra.util.MathException;
import jalgebra.impl.object.Integer;


/**
 * Any Integer-based Set should extend this
 */
public class IntegersSet implements Set {



	// Set
	public boolean in(Object x) {
    	return (x instanceof Integer);
    }

    public boolean eq(Object x, Object y) {
    	if (in(x) && in(y)) return _eq(x,y);
   		else throw new MathException("Tried to equals on non-Integer.");
	}
    public boolean _eq(Object x, Object y) {
    	return (((Integer)x).get()==((Integer)y).get());
    }

    public Object copy(Object o) {
		if (in(o)) return _copy(o);
		else throw new MathException("Tried to copy with non-Integer element.");
    }
    public Object _copy(Object o) {
    	return new Integer((Integer)o);
    }


}