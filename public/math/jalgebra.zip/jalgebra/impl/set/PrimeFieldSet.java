package jalgebra.impl.set;

import java.math.BigInteger;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.Integer;
import jalgebra.impl.ring.Integers;



/**
 * The set of numbers from a PimeField
 */
public class PrimeFieldSet implements Set {


	protected Integers Z = new Integers();
	protected AbelianGroup Zadd = (AbelianGroup)Z.add();
	protected Monoid Zmul = (Monoid)Z.mul();
	
	protected Integer zero = (Integer)Zadd.neutral();
	protected Integer one = (Integer)Zmul.neutral();
	protected Integer minusone = new Integer(-1);;
	protected Integer two = new Integer(2);
	protected Integer order;
	protected Integer negorder;
	protected Object lwrbound;
	protected Object uprbound;




	// Consturctor
    /**
     *	isProbablePrime
     *		public boolean isProbablePrime(int certainty)
     *
     *	maybe i'll use another one here...
     *  7 stands for > 99% certainty 1-(1/2)^7
     */
    private boolean primalitycheck(int p) {
    	Integer i = new Integer(p);
    	BigInteger I = new BigInteger(i.toString());
    	
    	if(I.isProbablePrime(7) == false) {
    		return false;
    	} else { //slower, safer check
    		int sqrtp = (int)java.lang.Math.sqrt((double)p);
    		if(sqrtp < 1) return false;
    		for(int j=2; j<=sqrtp;j++){
				if(p%j==0) return false;
    		}
    		return true;
    	}
    }

    public PrimeFieldSet(int p) {
		if (!primalitycheck(p)) throw new MathException("Prime needed for constructor. Usage: FiniteField(int Prime, int Exponent)");

    	order = new Integer(p);
    	negorder = (Integer) Z._copy(order);
    	Zadd.inv(negorder);
    	
    	if(p==2) {
    		lwrbound = new Integer(-1);
    		uprbound = new Integer(2);
    	} else {
    		lwrbound = Z.copy(order);
    		Zadd._op(lwrbound,one);
    		uprbound = Z._div(lwrbound,two);
    		Zadd._op(lwrbound,uprbound);
    		Zadd._inv(lwrbound);
    	}
    }




	//Set
	/**
	 * x in PrimeField must be integer and 0 <= x < order.
	 */
	public boolean in(Object _x) {
		if(!Z.in(_x)) return false;
		return (Z._slt(lwrbound,_x) && Z._slt(_x,uprbound));
	}

    public boolean eq(Object x, Object y) {
    	if (in(x) && in(y)) return _eq(x,y);
   		else throw new MathException("Tried to equals on non-PrimeField elements.");
	}
    public boolean _eq(Object x, Object y) {
    	return Z._eq(x,y);
    }

    public Object copy(Object o) {
		if (in(o)) return _copy(o);
		else throw new MathException("Tried to copy with non-PrimeField element.");
    }
    public Object _copy(Object o) {
    	return Z._copy(o);
    }

    
}