package jalgebra.impl.ring;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.intf.combination.*;
import jalgebra.intf.order.PartialOrder;
import jalgebra.impl.object.Integer;
import jalgebra.impl.set.IntegersSet;
import jalgebra.impl.group.IntegersAddGroup;
import jalgebra.impl.group.IntegersMulMonoid;
import jalgebra.algo.*;



/**
 * The ring of integers is the set of integers ..., -2, -1, 0, 1, 2, ..., which form a ring. 
 *
 *
 * Problems: 
 * - is there a better way to do pow();
 * 
 * Remarks:
 * -- modpow works without creating too many objects but is still recursive.
 * -- modpow needed divions in case modulo is zero. so in a = b*m+m%a this would be b.
 * - modpow works without recursion now but is still not optimized
 * - argh modpow cannot be called from a superobject if _mul or any of these
 *   operations are overridden... this is java problem/feature...
 * - order is implemented by smaller(obj,obj) and bigger(obj,obj)
 *
 * http://mathworld.wolfram.com/RingofIntegers.html
 **/


public class Integers extends IntegersSet implements OrderedEuclideanRing {


	private IntegersAddGroup add = new IntegersAddGroup();
	private IntegersMulMonoid mul = new IntegersMulMonoid();




	// Ring
	public Semigroup add() { return add; }
	public Semigroup mul() { return mul; }




	// EuclideanRing
	public int norm(Object x) {
		if (in(x)) return _norm(x);
		else throw new MathException("Tried to norm with non-Integer element.");
	}
	public int _norm(Object x) {
		int i = ((Integer)x).get();
		return i < 0 ? -i : i;
	}

    public void mod(Object x, Object y) {
     	if (in(x) && in(y))	_mod(x,y);
   		else throw new MathException("Tried to modulo with non-Integer.");
    }
	public void _mod(Object _x, Object _y) {
		int x = ((Integer)_x).get();
		int y = ((Integer)_y).get();
		((Integer)_x).set(x%y);
	}

	public Object div(Object x, Object y) {
		if (in(x) && in(y)) return _div(x,y);
		else throw new MathException("Tried to div with non-Integer element.");
	}
	public Object _div(Object _x, Object _y) {
		int x = ((Integer)_x).get();
		int y = ((Integer)_y).get();

		_mod(_x,_y);
		return new Integer(x/y);
	}




	// PartialOrder
	public boolean slt(Object _x, Object _y) {
     	if (in(_x) && in(_y)) return _slt(_x,_y);
		else throw new MathException("Tried to smallerthen with non-Integer element.");
	}
	public boolean _slt(Object _x, Object _y) {
		int x = ((Integer)_x).get();
		int y = ((Integer)_y).get();
		return x<y;
	}

	public boolean sle(Object _x, Object _y) {
     	if (in(_x) && in(_y)) return _sle(_x,_y);
		else throw new MathException("Tried to smallerorequals with non-Integer element.");
	}
	public boolean _sle(Object _x, Object _y) {
		int x = ((Integer)_x).get();
		int y = ((Integer)_y).get();
		return x<=y;
	}

	public boolean bgt(Object _x, Object _y){
     	if (in(_x) && in(_y)) return _bgt(_x,_y);
		else throw new MathException("Tried to biggerthen with non-Integer element.");
	}
	public boolean _bgt(Object _x, Object _y) {
		int x = ((Integer)_x).get();
		int y = ((Integer)_y).get();
		return x>y;
	}
	
	public boolean bge(Object _x, Object _y){
     	if (in(_x) && in(_y)) return _bge(_x,_y);
		else throw new MathException("Tried to biggerorequals with non-Integer element.");
	}
	public boolean _bge(Object _x, Object _y) {
		int x = ((Integer)_x).get();
		int y = ((Integer)_y).get();
		return x>=y;
	}
	




/****
 *
 *
 * Main
 *
 *
 ****/

    public static void main(String[] args) {
		Integers Z = new Integers();
		Integer p = new Integer(3);
		Integer q = new Integer(10);
		Integer k = new Integer(7);
		
		System.out.println(p+" , "+k+" , "+q);
		RingAlgorithm._modPow(Z,p,k,Z,q);
		System.out.println(p+" , "+k+" , "+q);
/*		Object oldp = Z._copy(p);
		Object oldq = Z._copy(q);
		Object g = Algorithm.euclid(Z,Z.add(),Z.mul(),p,q);
		System.out.println(g+" , "+p+" , "+q);
		Z.mul()._op(p,oldp);
		Z.mul()._op(q,oldq);
		System.out.println(g+" = "+p+" + "+q);
*/   }
    
}