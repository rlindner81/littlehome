package jalgebra.impl.ring;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.intf.combination.*;
import jalgebra.algo.*;
import jalgebra.impl.field.*;
import jalgebra.impl.object.Integer;
import jalgebra.impl.object.*;
import jalgebra.impl.group.*;
import jalgebra.impl.set.*;




/** 
 * The ring R[X] of polynomials in a variable X. 
 *
 *
 * Problems: 
 * - zero and one can't be final but noone should change them! The problem is,
 *   that you don't know the ring your over when you create them...
 * 
 * Remarks:
 * - it is still to prove and maybe use whether or not 
 *   R[X] is a Euclidean Ring iff R is a field.
 * 
 * http://mathworld.wolfram.com/PolynomialRing.html 
 */  


public class PolynomialRing extends PolynomialRingSet implements EuclideanRing {


	private PolynomialRingAddGroup add;
	private PolynomialRingMulMonoid mul;


	// Constructors
	public PolynomialRing(Ring _R) {
		super(_R);
		add = new PolynomialRingAddGroup(R);
		mul = new PolynomialRingMulMonoid(R);
	}



	
	// Ring
    public Semigroup add() { return add; }
    public Semigroup mul() { return mul; }





	// EuclideanRing
	private void euclideanCheck() {
		if(!(R instanceof Field)) throw new MathException("This ring is not euclidean.");
	}


	public int norm(Object x) {
		if (in(x)) return _norm(x);
		else throw new MathException("Tried to norm with non-Polynomial.");
	}
	public int _norm(Object x) {
		return ((Polynomial)x).getDegree();
	}


    public void mod(Object x, Object y) {
		euclideanCheck();
     	if (in(x) && in(y))	_mod(x,y);
   		else throw new MathException("Tried to modulo with non-Polynomial.");
    }
	public void _mod(Object _x, Object _y) {
		_div(_x,_y); //not efficient...
	}


	public Object div(Object x, Object y) {
		euclideanCheck();
		if (in(x) && in(y)) return _div(x,y);
		else throw new MathException("Tried to div with non-Integer element.");
	}
	public Object _div(Object _f, Object _g) {
		Polynomial f = (Polynomial)_f;
		Polynomial g = (Polynomial)_g;	
		if(_eq(f,zero)) return new Polynomial(zero);
		if(_eq(g,zero)) throw new MathException("Bah... tried to divide by the zero polynomial.");
		
		int fd = f.getDegree();
		int gd = g.getDegree();
		
		if(fd<gd) return new Polynomial(zero);
		
		Object gco = g.getCo(gd);
		Object ginv = R._copy(gco);
		((Group)R.mul())._inv(ginv);

		Polynomial inv = new Polynomial(R);
		Polynomial h = new Polynomial(R);
		
		Object fco,hco,hminus;

		int hd = fd-gd;
		inv.setDegree(hd);

		while(fd>=gd) {
			hd = fd-gd;
			h.setDegree(hd);

			fco = f.getCo(fd);
			hco = R._copy(ginv);

			R.mul()._op(hco,fco);
			h.setCo(hd,hco);
		
			add._op(inv,h);
			add._inv(h);
		
			mul._op(h,g);
			add._op(f,h);
		
			fd = f.getDegree();
			add.setNeutral(h);
		}
		return inv;
	}




	//Additional Stuff
	/** Constructs a polynomial associated with the given Integer and Field.
	 * Input Z, i, F
	 * Output p
	 * Where Z is the Integers, i is the number we want to polynomialize
	 * and F the Field over which p will be a polynomial.
	 * 
	 * i is calculated to the basis 'order of F' and then the digits are used
	 * as coefficients. This is done in such a fashion that the digits are 
	 * elements of F in the new representation system, i.e. they do not exceed
	 * +- order/2.
	 *
	 * By evaluating the polynomial at the order of F we should get back the 
	 * number i we started out with.
	 *
	 */
	public static Object construct(OrderedEuclideanRing Z, Object _i, FiniteField F){
		AbelianGroup Zadd = (AbelianGroup)Z.add();
		Monoid Zmul = (Monoid)Z.mul();
		
		if(Zadd._isNeutral(_i)) return new Polynomial(F);

		Object zero = Zadd.neutral();
		Object one = Zmul.neutral();
		Object minusone = Z._copy(one);
		Zadd._inv(minusone);
			
		Object i = Z._copy(_i);
		Object ord = F.getOrder();
		Object minusord = Z.copy(ord);
		Zadd._inv(minusord);
		
		Object lwrbound = F.getLwrBound();
		Object uprbound = F.getUprBound();

		Object co;
		int j = 0;
		
/*		System.out.println(ord);
		System.out.println(minusord);
		System.out.println(uprbound);
		System.out.println(lwrbound);
		System.out.println();
*/		
		Polynomial f = new Polynomial(F);
		while(!Zadd._isNeutral(i)){
			f.setDegree(j);
			co = Z._copy(i);
			i = Z._div(co,ord);
			
			if(Z._sle(uprbound,co)) {
				Zadd._op(co,minusord);
				Zadd._op(i,one);
			}
			if(Z._sle(co,lwrbound)) {
				Zadd._op(co,ord);
				Zadd._op(i,minusone);
			}

			f.setCo(j,co);
			j++;
		}
		return f;
	}

	/** Adapts a polynomial from Z[X] to be one over F[X].
	 * This is done by changing the coeefficients into the right range.
	 *
	 */
	public static void adaptPolynomial(Object _f, Integers Z, FiniteField F) {
		
		Polynomial f = (Polynomial)_f;
		int fd = f.getDegree();
		Group Zadd = (Group)Z.add();
		Monoid Zmul = (Monoid)Z.mul();
		Object zero = Zadd.neutral();
		
		Object lwrbound = F.getLwrBound();
		Object uprbound = F.getUprBound();

		Object order = F.getOrder();
		Object negorder = Z.copy(order);
		Zadd.inv(negorder);

		//make f a polynomial over F.
		Object co;
		for(int i=0;i<=fd;i++) {
			co = f.getCo(i);
			if(Z.eq(co,zero)) continue;
    		if(Z.slt(co,zero)) {
			   	while(Z.sle(co,lwrbound)) Zadd.op(co,order);
    		} else {
				while(Z.bge(co,uprbound)) Zadd.op(co,negorder);
    		}
		}

		//correct f's degree
		for(int i=fd;i>=0;i--){
			co = f.getCo(i);
			if(co!=null && !Zadd._isNeutral(co)) 
				if (i==fd) { break; }
				else { f.setDegree(i); break; }
			if(i==0) { f.setDegree(Polynomial.MINUS_INFINITY); break; }
		}
	
	}

	/** Checks if a polynomial is irreducible.
	 * Input f, Z, F
	 * Output boolean
	 * Where f is the polynomial to check, Z is the Integers, and F the Field which
	 * we want to check irreducibility over
	 *.
	 */
	public boolean checkIrreducible(Object _f, Integers Z, FiniteField F) {
		if (!(_f instanceof Polynomial)) throw new MathException("Called checkIrreducible with a non-Polynomial Object.");
		//adapt the polynomial to the field
		PolynomialRing.adaptPolynomial(_f, Z, F);

		Polynomial f = (Polynomial)_f;
		Object fdeg = new Integer(f.getDegree());

		Group Zadd = (Group)Z.add();
		Monoid Zmul = (Monoid)Z.mul();
		Object zero = Zadd.neutral();
		Object one = Zmul.neutral();

		//special cases
		if(eq(f,this.zero)){ throw new MathException("Called checkIrreducible with the zero polynomial."); }
		if(Z.sle(fdeg, one)){ return false; } //linear or unit element
		if(Z.eq(f.getCo(0),zero)){ return false; } //constant term equals zero
		
		
		System.out.println("Checking irreducibility of...");
		System.out.println(_f);


		Object uprbound = F.getUprBound();
		Object order = F.getOrder();
		
		//create 'biggest' polynomial of half the degree
		
		Object minusone = new Integer(-1); 
		Object two = new Integer(2);
		
		Object halfdeg = Z.copy(fdeg);
		halfdeg = Z.div(halfdeg, two);
		Zadd.op(halfdeg, Zmul.neutral());
		
		Object creator = Z.copy(order);
		GroupAlgorithm._pow(Zmul,creator,Z,halfdeg);
		
		if(!Z.eq(order,two)){
			creator = Z.div(creator, two);
		} else {
			Zadd.op(creator, minusone);
		}


/*
 *		System.out.println("Order:");
		System.out.println(order);
		System.out.println("Creator:");
		System.out.println(creator);
		System.out.println("Uprbound:");
		System.out.println(F.getUprBound());
		System.out.println(construct(Z, F.getUprBound(), F));
*/		

		//start counting downwards to see if we find a divisor
		Polynomial divisor;
		Object leadingco;
		Object checker;
		for(;Z.sle(uprbound,creator); Zadd.op(creator,minusone)) {
			// eleminate polynomials that are divided by X
			checker = Z.copy(creator);
			Z.mod(checker,order);
			if (Zadd.isNeutral(checker)) continue;
			
			divisor = (Polynomial)construct(Z, creator, F);
			
			// eleminiate polynomials with leading coefficients neq one
			leadingco = divisor.getCo(divisor.getDegree());
			if (!Zmul.isNeutral(leadingco)) continue;
			
			Object modulo = copy(f);
			Object quotient = div(modulo,divisor);

			if(eq(modulo,this.zero)){
				System.out.println("This polynomial is divisible by:");
				System.out.println(quotient);
				System.out.println(divisor);
				return false;	
			}
		}

		return true;
	}


    public static void main(String[] args) {
    	Integers Z = new Integers();
    	PrimeField F = new PrimeField(7);
		PolynomialRing RX = new PolynomialRing(F);

		Integer[] a = {new Integer(-1),new Integer(1), new Integer(1), new Integer(1), new Integer(1)};
		Polynomial pa = new Polynomial(Z,a);

		System.out.println("sent in: "+pa);
		System.out.println(RX.checkIrreducible(pa, Z, F));
    }
    
}