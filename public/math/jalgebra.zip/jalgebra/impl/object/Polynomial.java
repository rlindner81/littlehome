package jalgebra.impl.object;

import java.util.Vector;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.Integer;
import jalgebra.impl.ring.Integers;
import jalgebra.util.MathException;

/**
 *  The simple object of a polynomial over an arbitrary ring.
 *
 *  Problems:
 *	- The constructor that is given both Ring and degree of the polynomial
 *    cannot check "given degree >= 0" before calling the superconstructor.
 *    I might have to construct any vector then check and adjust the Vector
 *    accordingly.
 *
 *  Remarks:
 *  - It turns out to be quite convenient to let the empty Vector represent the
 *    Zero polynomial. In fact every coefficient spot that is ever empty 
 *    should be considered zero.
 *
 *
 **/


public class Polynomial extends Vector {

	public final static int MINUS_INFINITY=java.lang.Integer.MIN_VALUE;
	private Ring R; // the ring we are working over
	private int d;		 // the degree of the polynomial, 

    /** constructs the zero polynomial */
    public Polynomial(Ring _R) {
		super();
		R = _R;
		d = MINUS_INFINITY;
    }

    /** constructs the dth power of X, 
	i.e., the polynomial 1 X^d + 0 X^d-1 + ... + 0 */
    public Polynomial(Ring _R, int _d) {
		super();
		
		if(_d<0) throw new MathException("Cannot construct polynomial with negative degree.");
		
		R = _R;
		d = _d;
		Object zero = ((Monoid)R.add()).neutral();
		Object one = ((Monoid)R.mul()).neutral();
		for (int n=0; n<d; n++)
			add(n,R._copy(zero));

		add(d,R._copy(one));
	}
    public Polynomial(Ring _R, Object[] a) {
    	super(a.length);
		R = _R;
		d = a.length-1;
		for (int n=0; n<a.length; n++) {
			if(!R.in(a[n])) throw new MathException("Tried to construct Polynomial with non-ring Elements.");
			add(n,a[n]);
		}
	}
    public Polynomial(Polynomial p) {
    	super((Vector)p);
		R = p.getRing();
		d = p.getDegree();
		Object o = null;
		for (int n=0; n<=d; n++) {
			o = getCo(n);
			if (o != null) {
				o = R._copy(o);
				setCo(n,o);
			}
		}

	}
	
	public int getDegree() {
		return d;
    }
   	public void setDegree(int _d) {
   		if (_d==MINUS_INFINITY) clear();
   		else setSize(_d+1);
		d = _d;
    }
	public Object getCo(int i) {
		return elementAt(i);
    }
	public void setCo(int i, Object _r) {
		set(i,_r);
    }
	
	// returns the index of the next lower degree nonzero coefficient or minusinfinity if there are none
	public int nextCo(int i) {
		Monoid add = (Monoid)R.add();
		
		i--;
		while(i>=0) {
			if(elementAt(i)!= null && !add._isNeutral(elementAt(i))) return i;
			i--;
		}
		return MINUS_INFINITY;
	}

	public Ring getRing() {
		return R;
	}

	public void _set(Vector v) {
		clear();
		if (v.isEmpty()) {
			d=MINUS_INFINITY;
			return;
		}
		
		for(int i=0;i<v.size();i++)
			add(i,v.elementAt(i));
        d = size()-1;
    }
	public void _set(Polynomial p) {
		_set((Vector)p);
		d=p.getDegree();
		R=p.getRing();
    }
	public Vector get() {
        return this;
    }
    
    public String toString() {
        StringBuffer s = new StringBuffer();
        
        if(isEmpty()) return s.append("[").append(0).append("]").toString();
        
        int gd = getDegree();
        for (int i=gd; i>=0;i--) {
			if(i!=gd) { s.append("+");}
        	if(elementAt(i)==null) { s.append("[null]*X^").append(i); continue; }
			if(i==0) { s.append("[").append(elementAt(i).toString()).append("]"); continue; }
			if(i==1) { s.append("[").append(elementAt(i).toString()).append("]").append("*X"); continue; }
	    	s.append("[").append(elementAt(i).toString()).append("]").append("*X^").append(i);
    	}
        
        return s.toString();
    }
	
	public static void main(String[] args) {
		Integers Z = new Integers();
		Integer[] a = {new Integer(1), new Integer(2), new Integer(3)};
		Polynomial p = new Polynomial(Z);
		Polynomial q = new Polynomial(Z,3);
		Polynomial ap = new Polynomial(Z,a);
		
		System.out.println(p.toString());
		System.out.println(q.toString());
		System.out.println(ap.toString());
	}

}