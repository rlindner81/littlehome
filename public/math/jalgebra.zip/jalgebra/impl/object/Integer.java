package jalgebra.impl.object;

import jalgebra.util.MathException;
import jalgebra.intf.structure.Ring;


public class Integer extends Object{

    private int val;

    // Default Value = 0;
    public Integer() {
        val = 0;
    }

    public Integer(int i) {
        val = i;
    }
    public Integer(Integer i) {
        val = i.get();
    }

    public void set(int i) {
        val = i;
    }

    public int get() {
        return val;
    }
    
    public String toString()
    {
        return java.lang.Integer.toString(val);
    }
    
    public static void main(String[] args) {
    	System.out.println(java.lang.Integer.MAX_VALUE);
    }
}

