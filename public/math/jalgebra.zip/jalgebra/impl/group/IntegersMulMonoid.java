package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.Monoid;
import jalgebra.impl.object.Integer;
import jalgebra.impl.set.IntegersSet;




/**
 * The multiplicative monoid of the integers.
 **/
public class IntegersMulMonoid extends IntegersSet implements Monoid {


	private final static Integer one = new Integer(1);




	// Semigroup
	public void op(Object x, Object y) {
     	if (in(x) && in(y)) _op(x,y);
   		else throw new MathException("Tried to multiply with non-Integer.");
 	}
    public void _op(Object x, Object y) {
    	((Integer)x).set(((Integer)x).get()*((Integer)y).get());
    }




	// Monoid
    public Object neutral() {
    	return one;
    }

    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x);
   		else throw new MathException("Tried to setNeutral with non-Integer.");
	}
    public void _setNeutral(Object x) {
    	((Integer)x).set(1);
    }

    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x);
   		else throw new MathException("Tried to check =1 with non-Integer.");
 	}
    public boolean _isNeutral(Object x) {
    	return _eq(x,one);
    }
	
	    
}