package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.AbelianGroup;
import jalgebra.impl.object.Integer;
import jalgebra.impl.set.IntegersSet;




/**
 * The additive abelian group of the integers.
 */
public class IntegersAddGroup extends IntegersSet implements AbelianGroup {

	private final static Integer zero = new Integer(0);




	// Semigroup
    public void op(Object x, Object y) {
     	if (in(x) && in(y)) _op(x,y);
   		else throw new MathException("Tried to add with non-Integer elements.");
    }
    public void _op(Object x, Object y) {
    	((Integer)x).set(((Integer)x).get()+((Integer)y).get());
    }




	// Monoid
    public Object neutral() {
    	return zero;
    }

    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x);
   		else throw new MathException("Tried to setNeutral with non-Integer elements.");
	}
    public void _setNeutral(Object x) {
    	((Integer)x).set(0);
    }

    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x);
   		else throw new MathException("Tried to isNeutral with non-Integer elements.");
	}
    public boolean _isNeutral(Object x) {
    	return _eq(x,zero);
    }
	



	// Group
    public void inv(Object x) {
    	if (in(x)) _inv(x);
   		else throw new MathException("Tried to additive inverse with non-Integer elements.");
    }
    public void _inv(Object _x) {
		int x = ((Integer)_x).get();
		if (x==0) return;
		((Integer)_x).set(-x);
    }

   
}