package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.*;
import jalgebra.impl.set.*;




/*.
 * The multiplicative monoid of a PolynomialRing.
 */
public class PolynomialRingMulMonoid extends PolynomialRingSet implements Monoid {




	// Constructors
	public PolynomialRingMulMonoid(Ring _R) {
		super(_R);
	}




	//Semigroup
	public void op(Object f, Object g) {
     	if (in(f) && in(g)) _op(f,g);
		else throw new MathException("Tried to mul with non-PolyRing element.");
	}
    public void _op(Object _f, Object _g) {
		if(_f == null  || _eq(_f,zero)) return;
		Polynomial f = (Polynomial)_f;
		Polynomial g = (Polynomial)_g;

		if(_g == null  || _eq(_g,zero)) { 
			f.setDegree(Polynomial.MINUS_INFINITY);
 			return;
 		}
		
		Polynomial h = new Polynomial(R); //zero Polynomial
		int fd = f.getDegree();
		int gd = g.getDegree();
		
		int hd = fd+gd;
		h.setDegree(hd);
		
		Object fco,gco,hco,hco_old;

		while (gd!=Polynomial.MINUS_INFINITY) {
			hd = fd+gd;
			fco = f.getCo(fd);
			gco = g.getCo(gd);
			
			hco = R._copy(fco);
			Rmul._op(hco,gco);
			
			hco_old = h.getCo(hd);
			if(hco_old!=null) Radd._op(hco,hco_old);
			
			h.setCo(hd,hco);
			fd = f.nextCo(fd);
			
			if(fd == Polynomial.MINUS_INFINITY) {
				gd = g.nextCo(gd);
				fd = f.getDegree();
			} 
		}
		
		f._set(h);
    }




	// Monoid
    public Object neutral() {
    	return one;
    }
    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x);
   		else throw new MathException("Tried to check =1 with non-ring element.");
	}
    public boolean _isNeutral(Object x) {
    	return _eq(x,one);
    }
    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x); 
    	else throw new MathException("Tried to =1 with non-ring element.");
    }
    public void _setNeutral(Object x) {
		Polynomial f = (Polynomial)x;
		f.clear();
		f.setDegree(0);
		Object rone = R.copy(Rmul.neutral());
		f.setCo(0,rone);
    }
}