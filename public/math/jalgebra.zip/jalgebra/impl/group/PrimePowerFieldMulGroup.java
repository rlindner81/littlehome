package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.algo.*;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.*;
import jalgebra.impl.set.*;




/*.
 * The multiplicative monoid of a PolynomialRing.
 */
public class PrimePowerFieldMulGroup extends PrimePowerFieldSet implements AbelianGroup {




	// Constructors
	public PrimePowerFieldMulGroup(FiniteField _F, Polynomial _p) {
		super(_F,_p);
	}




	//Semigroup
	public void op(Object f, Object g) {
     	if (in(f) && in(g)) _op(f,g);
		else throw new MathException("Tried to mul with non-PrimePowerField element.");
	}
    public void _op(Object _f, Object _g) {
		Rmul._op(_f,_g);

		Polynomial f = (Polynomial)_f;
		int fd = f.getDegree();
		if(fd<pd) return;
		R._mod(_f,p);
    }




	// Monoid
    public Object neutral() { return Rmul.neutral(); }


    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x);
   		else throw new MathException("Tried to check =1 with non-PrimePowerField element.");
	}
    public boolean _isNeutral(Object x) { return Rmul._isNeutral(x); }


    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x); 
    	else throw new MathException("Tried to =1 with non-PrimePowerField element.");
    }
    public void _setNeutral(Object x) { Rmul._setNeutral(x); }




	// Group
    public void inv(Object x) {
    	if (in(x)) _inv(x);
		else throw new MathException("Tried to find multiplicative inverse of non-PrimeField element.");
	}
    public void _inv(Object x) {
    	if(Radd._isNeutral(x)) throw new MathException("Tried to invert zero in PrimePowerField.");
		if(_isNeutral(x)) return;
		
		Object irr = R._copy(p);
		
		Polynomial gcd = (Polynomial)RingAlgorithm._euclid(R,x,irr);
		
		//here it gets complicated.
		//check that we have a unit element, i.e. degree 0.
		int gd = gcd.getDegree();
		if(gd!=0) throw new MathException("Polynom used to construct PrimePowerField was not irreducible or Euclid error.");

		//check it is not zero.
		Object o = gcd.getCo(0);
		if(o == null || Fadd._isNeutral(o)) throw new MathException("Euclid error.");
		
		//invert it in the groundfield and multiply it back into the result
		Fmul.inv(o);
		_op(x,gcd);
	}
}