package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.AbelianGroup;
import jalgebra.impl.object.Integer;
import jalgebra.impl.set.PrimeFieldSet;




/**
 * The additive abelian group of a PrimeField.
 */
public class PrimeFieldAddGroup extends PrimeFieldSet implements AbelianGroup {

	


	// Constructors
	public PrimeFieldAddGroup(int i) {
		super(i);
	}



	// Semigroup
    public void op(Object x, Object y) {
     	if (in(x) && in(y)) _op(x,y);
   		else throw new MathException("Tried to add with non-PrimeField element.");
    }
    public void _op(Object x, Object y) {
    	Z.add()._op(x,y);
    	if(Z._sle(x,lwrbound)) Z.add()._op(x,order);
    	if(Z._bge(x,uprbound)) Z.add()._op(x,negorder);
    }




	// Monoid
    public Object neutral() { return zero; }

    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x);
   		else throw new MathException("Tried to setNeutral with non-PrimeField element.");
	}
    public void _setNeutral(Object x) {	Zadd._setNeutral(x); }

    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x);
   		else throw new MathException("Tried to isNeutral with non-PrimeField element.");
	}
    public boolean _isNeutral(Object x) { return Zadd._isNeutral(x); }
	



	// Group
    public void inv(Object x) {
    	if (in(x)) _inv(x);
   		else throw new MathException("Tried to find additive inverse of non-PrimeField element.");
    }
    public void _inv(Object x) {
    	if(Z._eq(order,two)) return;
    	Zadd._inv(x);
    }

   
}