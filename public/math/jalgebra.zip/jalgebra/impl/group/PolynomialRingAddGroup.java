package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.*;
import jalgebra.impl.set.*;




/*.
 * The additive abelian group of a PolynomialRing.
 */
public class PolynomialRingAddGroup extends PolynomialRingSet implements AbelianGroup {




	// Constructors
	public PolynomialRingAddGroup(Ring _R) {
		super(_R);
	}




	// Semigroup
    public void op(Object x, Object y) {
     	if (in(x) && in(y)) _op(x,y);
   		else throw new MathException("Tried to add with non-ring element.");
    }


    /** Polynomial Addition.
     * Idea:
     * - solve trivial cases, where one summand is zero
     * - find which one has bigger degree and make f have that degree
     * - add g to f where it has objects and not null-references
     * - correct the degree of the outcome
     */
    public void _op(Object _f, Object _g) {
		Polynomial f = (Polynomial)_f;
		Polynomial g = (Polynomial)_g;

/*
		System.out.println("\n Before: ");
		System.out.println("f: "+f);
		System.out.println("fs: "+f.size());
		System.out.println("fd: "+f.getDegree());
		System.out.println("g: "+g);
		System.out.println("gs: "+g.size());
		System.out.println("gd: "+g.getDegree());
*/
		
		//solve trivial cases, where one summand is zero
		if(_eq(_g,zero)) return;
		if(_eq(_f,zero)) {
			f._set((java.util.Vector)g);
			f.setDegree(g.getDegree());
			return;
		}

		int fd = f.getDegree();
		int gd = g.getDegree();


		//find which one has bigger degree and make f have that degree
		if(gd>fd) { f.setDegree(gd); fd = gd; }

		//add g to f where it has objects and not null-references
		Object fco,gco;
		for(int i=0;i<=gd;i++){
			gco = g.getCo(i);
			fco = f.getCo(i);
			if(gco==null || Radd._isNeutral(gco)) continue;
			if(fco==null) { f.setCo(i,R._copy(gco)); continue; }
			Radd._op(fco,gco);
		}

		//correct the degree of the outcome
		for(int i=fd;i>=0;i--){
			fco = f.getCo(i);
			if(fco!=null && !Radd._isNeutral(fco)) 
				if (i==fd) { break; }
				else { f.setDegree(i); break; }
			if(i==0) { f.setDegree(Polynomial.MINUS_INFINITY); break; }
		}

/*
		System.out.println("\n After: ");
		System.out.println("f: "+f);
		System.out.println("fs: "+f.size());
		System.out.println("fd: "+f.getDegree());
		System.out.println("g: "+g);
		System.out.println("gs: "+g.size());
		System.out.println("gd: "+g.getDegree());
*/

    }




	// Monoid requirements
    public Object neutral() {
    	return zero;
    }
    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x); 
    	else throw new MathException("Tried to check =0 with non-ring element.");
   	}
    public boolean _isNeutral(Object x) {
    	return ((Polynomial)x).isEmpty();
    }
    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x); 
    	else throw new MathException("Tried to =0 with non-ring element.");
    }
    public void _setNeutral(Object x) {
		Polynomial f = (Polynomial)x;
		f.setDegree(Polynomial.MINUS_INFINITY);
    }
    



	// AbelianGroup requirements
    public void inv(Object f) {
     	if (in(f)) _inv(f);
		else throw new MathException("Tried to addinv with non-PolyRing element.");
    }
    public void _inv(Object _f) {
    	Polynomial f = (Polynomial)_f;
		Object o;
		for (int i=0;i<=f.getDegree();i++) {
			o = f.getCo(i);
			if (o != null) Radd._inv(o);
		}
    }
}