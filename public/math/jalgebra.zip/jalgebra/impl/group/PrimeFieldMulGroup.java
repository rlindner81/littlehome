package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.Integer;
import jalgebra.impl.set.PrimeFieldSet;
import jalgebra.algo.*;




/**
 * The multiplicative monoid of the integers.
 **/
public class PrimeFieldMulGroup extends PrimeFieldSet implements AbelianGroup {

	


	// Constructors
	public PrimeFieldMulGroup(int i) {
		super(i);
	}




	// Semigroup
	public void op(Object x, Object y) {
     	if (in(x) && in(y)) _op(x,y);
   		else throw new MathException("Tried to multiply with non-PrimeField element.");
 	}
    public void _op(Object x, Object y) {
    	Z.mul()._op(x,y);
    	if(Z._eq(x,zero)) return;
    	if(Z._slt(x,zero)) {
	    	while(Z._sle(x,lwrbound)) Z.add()._op(x,order);
    	} else {
	    	while(Z._bge(x,uprbound)) Z.add()._op(x,negorder);
    	}
    }




	// Monoid
    public Object neutral() {
    	return one;
    }

    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x);
   		else throw new MathException("Tried to setNeutral with non-PrimeField element.");
	}
    public void _setNeutral(Object x) {
    	Zmul._setNeutral(x);
    }

    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x);
   		else throw new MathException("Tried to isNeutral with non-PrimeField element.");
 	}
    public boolean _isNeutral(Object x) {
    	return Zmul._isNeutral(x);
    }
	



	// Group
    public void inv(Object x) {
    	if (in(x)) _inv(x);
   		else throw new MathException("Tried to find multiplicative inverse of non-PrimeField element.");
    }
    public void _inv(Object x) {
    	if(Zadd._isNeutral(x)) throw new MathException("Tried to invert zero in PrimeField.");
		if(_isNeutral(x) || _eq(x,minusone)) return;
		
		Object p = Z._copy(order);
		
		Object gcd = RingAlgorithm._euclid(Z,x,p);
		
		// no need to use modulo here.
		
		// as 1 and -1 are the only units in Z it suffices to multiply the result by gcd
		// normally you would use gcd^-1
		Zmul._op(x,gcd);
		
	}


}