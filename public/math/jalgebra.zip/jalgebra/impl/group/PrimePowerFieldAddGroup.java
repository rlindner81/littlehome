package jalgebra.impl.group;

import java.lang.Object;
import jalgebra.util.MathException;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.*;
import jalgebra.impl.set.*;




/*.
 * The additive abelian group of a PrimePowerField.
 */
public class PrimePowerFieldAddGroup extends PrimePowerFieldSet implements AbelianGroup {




	// Constructors
	public PrimePowerFieldAddGroup(FiniteField _F, Polynomial _p) {
		super(_F,_p);
	}




	// Semigroup
    public void op(Object x, Object y) {
     	if (in(x) && in(y)) _op(x,y);
   		else throw new MathException("Tried to add with non-PrimePowerField element.");
    }
    public void _op(Object _f, Object _g) { Radd._op(_f,_g); }




	// Monoid requirements
    public Object neutral() { return Radd.neutral(); }


    public boolean isNeutral(Object x) {
    	if (in(x)) return _isNeutral(x); 
    	else throw new MathException("Tried to check =0 with non-PrimePowerField element.");
   	}
    public boolean _isNeutral(Object x) { return Radd._isNeutral(x); }


    public void setNeutral(Object x) {
    	if (in(x)) _setNeutral(x); 
    	else throw new MathException("Tried to setZero with non-PrimePowerField element.");
    }
    public void _setNeutral(Object x) { Radd._setNeutral(x); }
    



	// AbelianGroup requirements
    public void inv(Object f) {
     	if (in(f)) _inv(f);
		else throw new MathException("Tried to addinv with non-PrimePowerField element.");
    }
    public void _inv(Object _f) { Radd._inv(_f); }
    
    
    
    
}