package jalgebra.impl.field;

import jalgebra.util.MathException;
import jalgebra.impl.group.*;
import jalgebra.intf.combination.*;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.Integer;
import jalgebra.impl.object.*;
import jalgebra.impl.ring.*;
import jalgebra.impl.set.*;
import jalgebra.algo.*;

/** The Primepower Field implementation.
 */


public class PrimePowerField extends PrimePowerFieldSet implements Field, EuclideanRing {


	protected PrimePowerFieldAddGroup add;
	protected PrimePowerFieldMulGroup mul;



	// Constructors
	public PrimePowerField(FiniteField _F, Polynomial _p) {
		super(_F, _p);
		if(!R.checkIrreducible(p,Z,F)) throw new MathException("Polynomial used to construct PowerField is not irreducible.");
		add = new PrimePowerFieldAddGroup(_F, _p);
		mul = new PrimePowerFieldMulGroup(_F, _p);
	}




	// Field
	public Semigroup add() { return add; }
	public Semigroup mul() { return mul; }
	public Object getOrder() { return order; }



	// EuclideanRing
	public int norm(Object x) {
		if (in(x)) return _norm(x);
		else throw new MathException("Tried to norm with non-PrimePowerField element.");
	}
	public int _norm(Object x) { return R._norm(x);	}

    public void mod(Object x, Object y) {
     	if (in(x) && in(y))	_mod(x,y);
   		else throw new MathException("Tried to modulo with non-PrimePowerField element.");
    }
	public void _mod(Object x, Object y) { R._mod(x,y); }

	public Object div(Object x, Object y) {
		if (in(x) && in(y)) return _div(x,y);
		else throw new MathException("Tried to div with non-PrimePowerField element.");
	}
	public Object _div(Object x, Object y) { return R._div(x,y); }








	public static void main(String[] args) {
		PrimeField F = new PrimeField(5);
		Integers Z = new Integers();
		Object zero = ((Monoid)Z.add()).neutral();
		Object one = ((Monoid)Z.mul()).neutral();
		System.out.println(F.getOrder());

		//irreducible of degree 2
		Integer[] a = {new Integer(2),new Integer(0),new Integer(1)};
		Polynomial pa = new Polynomial(F,a);
		PrimePowerField FX = new PrimePowerField(F, pa);
		Group FXadd = (Group)FX.add();
		Group FXmul = (Group)FX.mul();

		Integer p = new Integer(-3);
		Integer q = new Integer(13);
		Integer k = new Integer(13);
		Object sum = FX.copy(FXmul.neutral());
		Polynomial pzero = new Polynomial(F);
		System.out.println(pzero);
		Object pc,pcinv;
		for(Object i = new Integer(-12); Z.sle(i,new Integer(12)); Z.add().op(i,one)){
			if(Z.eq(i,zero)) continue;
			System.out.println("\ni: "+i);
			pc = PolynomialRing.construct(Z, i, F);
			pcinv = FX.copy(pc);
			System.out.println(pc);
			System.out.println(((Polynomial)pc).getDegree());
			System.out.println(((Polynomial)pc).size());
			FXmul.inv(pcinv);
			System.out.println(pcinv);
			System.out.println(((Polynomial)pcinv).getDegree());
			System.out.println(((Polynomial)pcinv).size());
			FXmul.op(pcinv,pc);
			System.out.println(pcinv);
			System.out.println(((Polynomial)pcinv).getDegree());
			System.out.println(((Polynomial)pcinv).size());
		}

    }

}