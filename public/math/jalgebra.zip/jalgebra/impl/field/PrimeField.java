package jalgebra.impl.field;

import java.math.BigInteger;
import jalgebra.util.MathException;
import jalgebra.impl.group.*;
import jalgebra.intf.structure.*;
import jalgebra.impl.object.Integer;
import jalgebra.impl.ring.Integers;
import jalgebra.impl.set.PrimeFieldSet;
import jalgebra.algo.*;

/**
 *	The PrimeField implementation.
 *	This should be a field of the form. Z/pZ for some prime p given in the 
 *	constructor.
 */


public class PrimeField extends PrimeFieldSet implements FiniteField, EuclideanRing {


	private PrimeFieldAddGroup add;
	private PrimeFieldMulGroup mul;




	// Constructors
	public PrimeField(int i) {
		super(i);
		add = new PrimeFieldAddGroup(i);
		mul = new PrimeFieldMulGroup(i);
	}




	// Field
	public Semigroup add() { return add; }
	public Semigroup mul() { return mul; }
	public Object getOrder() { return order; }




	// FiniteField
	public Object getUprBound() { return uprbound; }
	public Object getLwrBound() { return lwrbound; }




	// EuclideanRing
	public int norm(Object x) {
		if (in(x)) return _norm(x);
		else throw new MathException("Tried to norm with non-PrimeField element.");
	}
	public int _norm(Object x) { return Z._norm(x);	}

    public void mod(Object x, Object y) {
     	if (in(x) && in(y))	_mod(x,y);
   		else throw new MathException("Tried to modulo with non-PrimeField element.");
    }
	public void _mod(Object x, Object y) { Z._mod(x,y); }

	public Object div(Object x, Object y) {
		if (in(x) && in(y)) return _div(x,y);
		else throw new MathException("Tried to div with non-PrimeField element.");
	}
	public Object _div(Object x, Object y) { 
		return Z._div(x,y); 
	}





	public static void main(String[] args) {
		PrimeField F = new PrimeField(23);
		Integers Z = new Integers();

		Integer p = new Integer(-3);
		Integer q = new Integer(13);
		Integer k = new Integer(13);
		
/*		System.out.println(p+" , "+q);
		F.add().op(p,q);
		System.out.println(p+" , "+q);
		F.mul().op(p,q);
		System.out.println(p+" , "+q);
	
*/		Object o,oinv,m,n;
		for(int i =-11;i<=11;i++) {
			if(i==0) continue;
			o = new Integer(i);
			oinv = new Integer(i);
			((Group)F.mul()).inv(oinv);
			System.out.println("\n"+o+" * "+oinv);
			F.mul()._op(o,oinv);
			System.out.println(o);

/*			m = F.copy(q);
			System.out.println("\n"+o+" , "+m);
			n = RingAlgorithm.euclid(F,o,m);
			System.out.println(n+" , "+o+" , "+m);
*/		}

		Object oldp = F._copy(p);
		Object oldq = F._copy(q);
/*
		F.mul().op(p,oldp);
		F.mul().op(q,oldq);
*/
		//2,3,5,7,11,13,
		//2,6,30,210,
	
    }

}