package jalgebra.intf.order;

import jalgebra.intf.structure.Set;

/**
 * http://mathworld.wolfram.com/PartialOrder.html
 * 
 * ...
 */

public interface PartialOrder extends Set {

	/**
	 * smaller then
	 */
	public boolean slt(Object _x, Object _y);
	public boolean _slt(Object _x, Object _y);

	/**
	 * smaller or equals
	 */
	public boolean sle(Object _x, Object _y);
	public boolean _sle(Object _x, Object _y);

	/**
	 * bigger then
	 */
	public boolean bgt(Object _x, Object _y);
	public boolean _bgt(Object _x, Object _y);
	
	/**
	 * bigger or equals
	 */
	public boolean bge(Object _x, Object _y);
	public boolean _bge(Object _x, Object _y);
	
}
