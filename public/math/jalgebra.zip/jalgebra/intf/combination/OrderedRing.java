package jalgebra.intf.combination;

import jalgebra.intf.structure.*;
import jalgebra.intf.order.PartialOrder;




/** A Ring together with a Partial Order
 */

public interface OrderedRing extends Ring, PartialOrder {
}

