package jalgebra.intf.combination;

import jalgebra.intf.structure.EuclideanRing;
import jalgebra.intf.order.PartialOrder;




/** A Euclidean Ring together with a Partial Order
 */

public interface OrderedEuclideanRing extends EuclideanRing, OrderedRing {
}

