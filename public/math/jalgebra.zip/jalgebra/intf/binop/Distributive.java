package jalgebra.intf.binop;

/**
  * Implement this interfaces iff Add, Mult satisfy the distributive law.
  */

public interface Distributive {

}