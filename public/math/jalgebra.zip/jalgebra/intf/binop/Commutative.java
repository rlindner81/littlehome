package jalgebra.intf.binop;

public interface Commutative {

// should be used when Add is commutative.

}