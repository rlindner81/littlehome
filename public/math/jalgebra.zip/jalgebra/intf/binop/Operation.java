package jalgebra.intf.binop;

import java.lang.Object;

public interface Operation {

    public void op(Object x, Object y);
    public void _op(Object x, Object y);

}

