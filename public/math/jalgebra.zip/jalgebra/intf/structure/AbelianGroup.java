package jalgebra.intf.structure;

import jalgebra.intf.binop.Commutative;

/**
 * Abelian means that the group is commutative.
 *
 * http://mathworld.wolfram.com/Group.html
 */

public interface AbelianGroup extends Group, Commutative {
}