package jalgebra.intf.structure;

/**
 * A monoid is a semigroup with an identity element.
 * It must contain at least one element. 
 *
 * http://mathworld.wolfram.com/Monoid.html
 *
 */

public interface Monoid extends Semigroup {

    public Object neutral();
    public void setNeutral(Object o);
    public void _setNeutral(Object o);
    public boolean isNeutral(Object o);
    public boolean _isNeutral(Object o);

}

