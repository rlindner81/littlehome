package jalgebra.intf.structure;

/**
 * A finite field is a bounded field. Every finite Field is ordered.
 */

public interface FiniteField extends Field {
	public Object getUprBound();
	public Object getLwrBound();
}