package jalgebra.intf.structure;

import jalgebra.intf.structure.Set;
import jalgebra.intf.binop.Distributive;



/**
 * A division algebra, also called a "division ring" or "skew field," is a ring
 * in which every nonzero element has a multiplicative inverse, but multiplication 
 * is not necessarily commutative.
 *
 * http://mathworld.wolfram.com/DivisionAlgebra.html
 *
 */

public interface DivisionAlgebra extends Set, Distributive {

	public AbelianGroup add();
	public Group mul();

}