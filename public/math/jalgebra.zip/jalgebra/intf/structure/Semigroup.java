package jalgebra.intf.structure;

import jalgebra.intf.structure.Set;
import jalgebra.intf.binop.Operation;

/**
 * A mathematical object defined for a set and a binary operator in which the 
 * operation is associative. This is the simplest structure interface that there 
 * is for a set in this package.
 *
 * http://mathworld.wolfram.com/Semigroup.html
 */

public interface Semigroup extends Set, Operation{

}

