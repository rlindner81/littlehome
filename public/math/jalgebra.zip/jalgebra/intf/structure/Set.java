package jalgebra.intf.structure;

/**
  * The interface kaye.math.intf.set.Set is an interface
  * for Objects that behave as sets of objects of class
  * java.lang.Object. 
  */

public interface Set {

/**
  * Method testing membership of an Object in this set.
  */
    public boolean in(Object x);

/**
  * Method testing equality of two elements of the set.
  * Note if either of Objects x,y are not members, then 
  * this will throw a kaye.maths.util.MathException exception.
  */
    public boolean eq(Object x, Object y);

/**
  * Method testing equality of two elements of the set.
  * Same as eq except the result is undefined 
  * (true/false/exception thrown?) if either 
  * of Objects x,y are not members.  In all other cases
  * it must return the same value as eq(x,y) and should be
  * at least as fast (and most likely faster).
  */
    public boolean _eq(Object x, Object y);

	//is not really a Set property, but I still need it.
	//supposed to create a new Object that contains the same as the old.
	public Object copy(Object o);
	public Object _copy(Object o);
}