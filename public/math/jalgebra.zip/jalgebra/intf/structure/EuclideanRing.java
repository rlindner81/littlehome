package jalgebra.intf.structure;

import jalgebra.intf.structure.Set;




/** 
 * A ring without zero divisors in which an integer norm 
 * and an associated division algorithm (ie, a Euclidean 
 * algorithm) can be defined. For signed integers, the usual 
 * norm is the absolute value and the division algorithm 
 * gives the ordinary quotient and remainder. For polynomials, 
 * the norm is the degree. 
 *
 * http://mathworld.wolfram.com/EuclideanRing.html
 */

public interface EuclideanRing extends Ring {
	
	/**
	 * Returns the norm of an Object.
	 */
	public int norm(Object x);
	public int _norm(Object x);
	
	
	/**
	 * Returns the equivalent of x%y.
	 */
	public void mod(Object x, Object y);
	public void _mod(Object x, Object y);

	/**
 	 * Division that returns x/y and changes x to x mod y.
 	 */
	public Object div(Object x, Object y);
	public Object _div(Object x, Object y);
}

