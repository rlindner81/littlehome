package jalgebra.intf.structure;

/**
 * A group G is a finite or infinite set of elements together with a binary 
 * operation which together satisfy the four fundamental properties of closure,
 * associativity, the identity property, and the inverse property.
 *
 * http://mathworld.wolfram.com/Group.html
 *
 */

public interface Group extends Monoid {

/**
  * Additive inverse of an element of the group.
  * (Throws an exception if x is not in the group.)
  */
    public void inv(Object x);

/**
  * Unchecked form of inverse().
  */
    public void _inv(Object x);

}