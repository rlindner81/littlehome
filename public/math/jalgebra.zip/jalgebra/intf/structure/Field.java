package jalgebra.intf.structure;

/**
 * A field is any set of elements which satisfies the field axioms for both 
 * addition and multiplication in other words it is a commutative division ring.
 *
 * http://mathworld.wolfram.com/Field.html
 */

public interface Field extends Ring {

	//add must be guaranteed to be an abelian group
	//mul must be guaranteed to be an abelian group
	public Object getOrder();
}