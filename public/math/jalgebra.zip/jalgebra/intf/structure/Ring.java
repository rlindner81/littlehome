package jalgebra.intf.structure;

import jalgebra.intf.structure.Set;
import jalgebra.intf.binop.Distributive;

/**
 * A ring R is a set together with two binary operators + and * (commonly interpreted 
 * as addition and multiplication, respectively) such that R is an Abelian group under 
 * addition and a semigroup under multiplication. 
 *
 * I require rings to have a multiplicative identity. These are sometimes 
 * called rings with one, or unit rings.
 *
 * http://mathworld.wolfram.com/Ring.html
 */

public interface Ring extends Set, Distributive {

	// this must be guaranteed to be an abelian group
	public Semigroup add();
	// this must be guaranteed to be a semigroup
	public Semigroup mul();

}

