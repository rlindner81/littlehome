package jalgebra.util;

/**
  * This is the general Exception class for exceptions
  * arising from use of the kaye.maths.* packages.  It
  * doesn't have to be declared.
  */
 
public class MathException extends Error
{

    public MathException(String message)
    {
        super(message);
    }

}

