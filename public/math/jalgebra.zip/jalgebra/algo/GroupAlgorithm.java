package jalgebra.algo;

import jalgebra.util.MathException;
import jalgebra.intf.combination.*;
import jalgebra.intf.structure.*;
import jalgebra.intf.order.*;


public class GroupAlgorithm {

	/** Simple Power Function for Semigroups up to Groups.
	 * Input Object x changes to x^y, Object y is unchanged
	 * SX semigroup contains x, RY ordered ring contains y
	 */

	public static void _pow(Semigroup SX, Object x, OrderedRing RY, Object y) {
		Object zero = ((Monoid)RY.add()).neutral();
		Object one = ((Monoid)RY.mul()).neutral();
		
		if(RY._eq(y,one)) return; //simple case
		if(RY._slt(y,zero)) {  // needs a group
			if(!(SX instanceof Group))
				throw new MathException("Can't take powers < 0 without a group.");
			
			((Group)SX)._inv(x);
			Object ycopy = RY._copy(y);
			((Group)RY.add())._inv(ycopy);
			y = ycopy; // the original y object remains unchanged
		} else if (RY._eq(y,zero)) { //need a monoid
			if(!(SX instanceof Monoid))
				throw new MathException("Can't take powers = 0 without a monoid.");
			
			((Monoid)SX)._setNeutral(x);
			return;
		}
		
		Object oldx = RY._copy(x);
		for(Object i = RY._copy(one); RY.slt(i,y); RY.add()._op(i,one))
			SX._op(x,oldx);
	}

}
