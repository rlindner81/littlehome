package jalgebra.algo;

import jalgebra.util.MathException;
import jalgebra.intf.combination.*;
import jalgebra.intf.structure.*;
import jalgebra.intf.order.*;


public class RingAlgorithm {



	/** Modulo Power Function
	 * Input EX, Object x changes to (x^y)%z, Object z is unchanged, RY, Object y also unchanged
	 * EX OrderedEuclideanRing contains x,z, RY ordered ring contains y
	 */
	public static void modPow(EuclideanRing EX, Object x, Object z, OrderedEuclideanRing EY, Object y) {
		if(EX.in(x) && EY.in(y) && EX.in(z)) 
			_modPow(EX,x,z,EY,y);
		else throw new MathException("Tried to gcd with non-Ring Elements.");
	}
	public static void _modPow(EuclideanRing EX, Object x, Object z, OrderedEuclideanRing EY, Object y) {
		AbelianGroup add = (AbelianGroup)EX.add();
		Monoid mul = (Monoid)EX.mul();

		AbelianGroup Yadd = (AbelianGroup)EY.add();
		Monoid Ymul = (Monoid)EY.mul();
		
		Object zero = add.neutral();
		Object one = mul.neutral();

		Object Yzero = Yadd.neutral();
		Object Yone = Ymul.neutral();

		//simple case power = 0
		if (EY._eq(y,Yzero)) { mul._setNeutral(x); return; }
		
		Object two = EY._copy(Yone);
		Yadd._op(two,Yone);
		
		Object a = EY._copy(Yone);
		Object b = EX._copy(one);
		
		Object ymod;
		Object diff;
		
		while(EY._slt(a,y)){
			Ymul._op(a,two);
		}

		if(!EY._eq(a,y)) a = EY._div(a,two);
		
		//a is now the biggest power of 2 smaller or equal to y
	
		while (!EY._eq(a,Yzero)) {
			ymod = EY._copy(y);
			EY._mod(ymod,a);
		
			diff = EY._copy(y);
			Yadd._inv(ymod);
			Yadd._op(diff,ymod);
			Yadd._inv(ymod);

			mul._op(b,b);
			if(!EY._eq(diff,Yzero)){
				mul._op(b,x);
			}
			EX._mod(b,z);

			y=ymod;
			if(!EY._eq(a,Yone)) {
				a = EY._div(a,two);
			} else {
				Yadd._setNeutral(a);
			}
		}

		add._setNeutral(x);
		add._op(x,b);
		return;
	}
	

	/**
	 * Greatest Common Devisior
	 * without calculating the coefficients and changing x,y
	 */
	public static Object gcd(EuclideanRing E, Object _x, Object _y) {
		if(E.in(_x) && E.in(_y)) return _gcd(E,_x,_y);
		else throw new MathException("Tried to gcd with non-Ring Elements.");
	}
	public static Object _gcd(EuclideanRing E, Object _x, Object _y) {
		AbelianGroup add = (AbelianGroup)E.add();
		Monoid mul = (Monoid)E.mul();
		
		Object zero = add.neutral();
		
		Object x = E._copy(_x);
		Object y = E._copy(_y);
		Object dummy;
		
		while(!E._eq(y,zero)){
			dummy = E._copy(x);
			E._mod(dummy,y);
			x = y;
			y = dummy;
		}
		return x;
	}


	
	/**
	 * Euclid (Greatest Common Devisior)
	 * with calculating the coefficients and changing x,y
	 * xbefore = copy(x);
	 * ybefore = copy(y);
	 * gcd = x * xbefore + y * ybefore
	 */
	public static Object euclid(EuclideanRing E, Object _x, Object _y) {
		if(E.in(_x) && E.in(_y)) return _euclid(E,_x,_y);
		else throw new MathException("Tried to euclid with non-Ring Elements.");
	}
	public static Object _euclid(EuclideanRing E, Object _x, Object _y) {
		AbelianGroup add = (AbelianGroup)E.add();
		Monoid mul = (Monoid)E.mul();

		Object zero = add.neutral();
		Object one = mul.neutral();
		
		Object x = E._copy(_x);
		Object y = E._copy(_y);
		Object dummy;
		Object b = null;
		
		if(add._isNeutral(y)){
			mul._setNeutral(_x);
			add._setNeutral(_y);
			return x;
		}

		Object c0 = E._copy(zero);
		Object c1 = E._copy(one);
		Object c2 = null;

		Object d0 = E._copy(one);
		Object d1 = null;
		Object d2 = null;

		dummy = E._copy(x);
		b = E._div(dummy,y);
		add._inv(b);

		d1 = b;

		x = y;
		y = dummy;
//int i=0;
		while(!add._isNeutral(y)){
//			i++;
			
/*			System.out.println("run i: "+i);
			System.out.println("x: "+x);
			System.out.println("y: "+y);
			System.out.println("dummy: "+dummy);
*/			
			dummy = E._copy(x);
			b = E._div(dummy,y);
			add._inv(b);
			
			x = y;
			y = dummy;

			c2 = E.copy(c1);
			mul._op(c2,b);
			add._op(c2,c0);
			c0 = c1;
			c1 = c2;

			d2 = E._copy(d1);
			mul._op(d2,b);
			add._op(d2,d0);
			d0 = d1;
			d1 = d2;

		}
		
		add._setNeutral(_x);
		add._op(_x,c0);
		add._setNeutral(_y);
		add._op(_y,d0);
		
		return x;
	}


}
